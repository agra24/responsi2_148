/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import database.Connector;
import main.Lomba;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class LombaModel {
    Connector con = new Connector();
     public void insertbelanja(Lomba Lomba){
        String query = "insert into item(judul,alur,orisinalitas,pemilihanKata,nilai) values (?,?,?)";
        PreparedStatement pstm;
        
        try{
           con.statement = con.koneksi.createStatement();
           pstm = con.koneksi.prepareStatement(query);
           pstm.setString (1, Lomba.getjudul());
           pstm.setDouble(2, Lomba.getalur());
           pstm.setDouble(3, Lomba.getorisinalitas());
           pstm.setDouble(4, Lomba.getpemilihanKata());
           pstm.setDouble(5, Lomba.nilai());
           pstm.executeUpdate();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }   
    }
    
    public ArrayList<Lomba> getLomba(){
        System.out.println("getlomba()");
        String query = "select * from lomba";
        PreparedStatement pstm;
        
        try{
           con.statement = con.koneksi.createStatement();
           pstm = con.koneksi.prepareStatement(query);
           ResultSet rs = pstm.executeQuery();
           ArrayList<belanja> list = new ArrayList<>();
           Lomba Lomba;
           while(rs.next()){
               Lomba = new Lomba(
                    rs.getString("judul"),
                    rs.getDouble("alur"),
                    rs.getDouble("orisinalitas"),
                    rs.getDouble("pemilihanKata"),
                    rs.getDouble("nilai")
               );
//               System.out.println(movie.getAlurCerita());
               list.add(Lomba);
           }
           return list;
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        return null;
    }
    
    public void updatelomba(lomba Lomba ){
        Connector con = new Connector();
        System.out.println("updatelomba()");
        Lomba.toString(); 
        String query = "update lomba set nilai =?, nilai=? where judul=?";
        PreparedStatement pstm;
        
        try{
           con.statement = con.koneksi.createStatement();
           pstm = con.koneksi.prepareStatement(query);
           pstm.setString (1, lomba.getjudul());
           pstm.setDouble(3, Lomba.getalur());
           pstm.setDouble(2, Lomba.getorisinalitas());
           pstm.setDouble(3, Lomba.nilai());
           pstm.executeUpdate();
           System.out.println("Update");
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
    public void deletelomba(Double judul){
        String query = "delete from lomba where judul = ?";
        PreparedStatement pstm;
        try {
            pstm = con.koneksi.prepareStatement(query);
            pstm.setDouble(1, judul);
            pstm.executeUpdate();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    public boolean isContainlomba(){
        System.out.println("isContainlomba()");
        try{
            String query = "select count(*) as num from lomba";
            PreparedStatement ptsm = con.koneksi.prepareStatement(query);
            con.statement = con.koneksi.createStatement();
            ResultSet rs = ptsm.executeQuery(query);
            rs.next();
            if(rs.getInt("num") > 0) return true;
        }catch(Exception e){
            System.err.println(e.getMessage());
        }
        return false;
    }

    private static class belanja {

        public belanja() {
        }
    }
    
}

