/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import Database.Connector;


public class Lomba {
    private String judul;
    private double alur;
    private double orisinalitas;
    private double pemilihanKata;
    private double nilai;

    
    
     public Lomba( double alur,double orisinalitas,double pemilihanKata {
       Connector con = new Connector();  
       
        
         this.alur= alur;
         this.orisinalitas = orisinalitas;
         this.pemilihanKata= pemilihanKata;
         
       // set();
    }
     public Lomba(String judul, double alur,double orisinalitas, double pemilihanKata, double nilai) {
         
         this.judul = judul;
         this.alur= alur;
         this.orisinalitas = orisinalitas;
         this.pemilihanKata= pemilihanKata;
         this.nilai= nilai;
    }

    public Lomba() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Lomba(int aInt) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    public String  getjudul(){
    return judul;
    }
    
    
    public double alur(){
    return alur;
    }
    
    public void setalur(double alur){
    this.alur = alur;
    }
    
    public double getorisinalitas(){
        return orisinalitas;
    } 
    
    public void setpemilihanKata(double pemilihanKata){
        this.pemilihankata = pemilihanKata;
    }
    
    public double nilai(){
        nilai = nilai*jmllomba;
        return nilai;
    }
    
    public void setnilai(double nilai){
       this.nilai = nilai; 
    }
    
    public double nilai(){
        return nilai;
    }
    
    public void setnilai(double nilai){
        this.nilai = nilai;
    }
    
    public double getjmllomba(){
        return nilai;
    }
    
    public void setjmllomba(double jmllomba){
        this.jmllomba = jmllomba;
    }
    
    @Override
    public String toString(){
     return "lomba{" + "judul=" + jdul + ", alur=" + alur + ", orisinalitas=" + orisinalitas + ", pemilihanKata=" + pemilihanKata + ", nilai=" + nilai + '}';   
    }
    
}

