/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import java.awt.event.ActionListener;
import javax.swing.JFrame;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author acer
 */
public class LombaView extends JFrame implements ActionListener{
    JLabel ljudul = new JLabel("judul");
    JLabel lalur = new JLabel("alur");
    JLabel lorisinalitas = new JLabel("orisinalitas");
    JLabel lpemilihanKata = new JLabel("pemilihanKata");
    JLabel lnilai = new JLabel("nilai");
    

    public JTextField tfjudul = new JTextField();
    public JTextField tfalur = new JTextField();
    public JTextField tforisinalitas = new JTextField();
    public JTextField tfpemilihanKata = new JTextField();
    public JTextField tfnilai = new JTextField();
  

    public JButton btnTambah = new JButton("Tambah");
    public JButton btnUpdate = new JButton("Update");
    public JButton btnDelete = new JButton("Delete");
    public JButton btnReset = new JButton("Clear");
 

    public JTable tabel;
    DefaultTableModel dtm;
    JScrollPane scrollPane;
    public Object namaKolom[] = {"judul", "alur", "orisinalitas", "pemilihanKata", "nilai"};


    public double getjudul(){
        return Double.valueOf( tfjudul.getText());
    }

    public String getalur(){
        return tfalur.getText();
    }
    
     public String getorisinalitas(){
        return tforisinalitas.getText();
    }
     
      public String getpemilihanKata(){
        return tfpemilihanKata.getText();
    }
      

    public double nilai(){
        return Double.valueOf(tfnilai.getText());   
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
