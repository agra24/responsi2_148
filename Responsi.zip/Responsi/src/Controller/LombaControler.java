/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import model.LombaModel;
import main.Lomba;

/**
 *
 * @author Lab Informatika
 */
public class LombaControler {
    private String judul;
    private double alur ;
    private double orisinalitas;
    private double PemilihanKata;  
    private double nilai;
    
    public LombaControler(lombaView view, LombaModel model){
        if(model.isContainlomba()){
            list = model.getlomba();
            String [][] data = convertData(list);
            view.tabel.setModel((new JTable(data, view.namaKolom)).getModel());
        }else{
            JOptionPane.showMessageDialog(null, "Data  Kosong");
        }
        view.btnTambah.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               String judul = view.getjudul();
               double alur = view.getalur();
               double alur = view.getorisinalitas();
               double alur = view.getpemilihanKata();
               double nilai = view.getnilai();
               if(isValid(judul, alur, orisinalitas, pemilihanKata, nilai)){
                    lomba Lomba = new Lomba(judul,alur,orisinalitas,pemilihanKata,nilai);
                    model.insertbelanja(Lomba);
               };
               list = model.getlomba();
               System.out.println(list.get(0).getjudul());
               String [][] data = convertData(list);
               view.tabel.setModel((new JTable(data, view.namaKolom)).getModel());
            }
        });
        
        view.btnUpdate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               System.out.println("btnUpdate");
               judul = view.getjudul();
               alur = view.getalur();
               orisinalitas = view.orisinalitas();
               pemilihanKata= view.getpemilihanKata();
               nilai = view.getnilai();
               lomba Lomba = new lomba(judul,alur,orisinalitas,pemilihanKata,nilai);
//                System.out.println(movie.getAkting());
               model.updatelomba(Lomba);
               list = model.getlomba();
               String [][] data = convertData(list);
               view.tabel.setModel((new JTable(data, view.namaKolom)).getModel());
            }
        });
        
        view.btnDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String judul = view.judul();
                model.deletelomba(judul);
                list = model.getlomba();
                String[][] data = convertData(list);
                view.tabel.setModel((new JTable(data, view.namaKolom)).getModel());
            }
        });
        
        view.tabel.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
                int baris = view.tabel.getSelectedRow();
                int kolom = view.tabel.getSelectedColumn();
                
                judul = Double.valueOf(view.tabel.getValueAt(baris, 0).toString());
                alur = view.tabel.getValueAt(baris, 1).toString(); 
                orisinalitas = Double.valueOf(view.tabel.getValueAt(baris, 2).toString());         
                view.tfjudul.setText(String.valueOf(judul));
                view.tfalur.setText(alur);                
                view.tforisinalitas.setText(String.valueOf(nilai));
            }
            
        });
        
        view.btnReset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.tfjudul.setText("");
                view.tfalur.setText("");
                view.tforisinalitas.setText("");
                view.tfpemilihanKata.setText("")
                view.tfnilai.setText("")
            }
        });
    }
    
    private boolean isValid( String judul, double alur){
        if((judul > 0) && (alur != null) && (nilai > 0))
            return true;
        else {
            return false;}
    }
    private String[][] convertData(ArrayList<lomba> list){
        String[][] data = new String[list.size()][3];
        
        for(int i = 0; i < list.size(); i++){
            data[i][0] = String.valueOf(list.get(i).getjudul);
            data[i][1] = list.get(i).getalur();
            data[i][2] = String.valueOf(list.get(i).getnilai());

        }
        
        return data;
    }
}

